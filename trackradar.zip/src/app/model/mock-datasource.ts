

import { Truck } from './truck';

const TRUCK_DATA: Truck[] = [
    { truckname: 'Truck 001', latitude: 20, longitude: 30 },
    { truckname: 'Truck 002', latitude: 22, longitude: 34},
    { truckname: 'Truck 003', latitude: 28, longitude: 78 }
]
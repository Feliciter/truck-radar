export interface Truck {
  truckname: string;
  latitude: number;
  longitude: number;  
}
